[ES]

*********************************************************************************************
Rellena este formulario ¡solo si optas a mención internacional! Si no, ¡elimina esta carpeta!
*********************************************************************************************

Coloca en esta carpeta todos los documentos firmados por los evaluadores internacionales. Sustituye "XXX" por las iniciales de cada evaluador. 

Por favor, comprueba que los "Formulario_07_informe_idoneidad_evaluador_internacional_XXX" tienen marcada la casilla "Acepto ser evaluador experto externo / I accept to be external evaluator".

¡Atención! Los internacionales externos deben usar firma electrónica siempre que sea posible. Es obligatoria para aquellos extranjeros que dispongan de ella. En caso de que no cuente con firma electrónica, se aceptará provisionalmente una firma digital no certificada (por ejemplo, escaneada o mediante Adobe Reader). Debido al elevado número de expertos extranjeros sin firma electrónica, esta medida se mantendrá hasta que la UPM implemente un sistema alternativo para ellos.

[EN]

***********************************************************************************************************
Fill out this form, only if you are applying for the international mention! If not, delete this folder!
***********************************************************************************************************

Place in this folder all the documents signed by the international evaluators. Replace "XXX" with the initials of each evaluator.

Please, check that the "Formulario_07_informe_idoneidad_evaluador_internacional_XXX" have the box "Acepto ser evaluador experto externo / I accept to be external evaluator" checked.

Warning! The suitability reports must be electronically signed whenever possible. This is mandatory for foreigners who have an electronic signature. For those without one, a provisional non-certified digital signature (e.g., scanned or via Adobe Reader) is acceptable. Given the high number of foreign experts lacking an electronic signature, this measure will remain in effect until UPM implements an alternative system.
