[ES]

Esta actividad es optativa. Si no la has realizado ninguna estancia, elimina esta carpeta.

[EN]

This activity is optional. If you have not completed any stay, delete this folder.
