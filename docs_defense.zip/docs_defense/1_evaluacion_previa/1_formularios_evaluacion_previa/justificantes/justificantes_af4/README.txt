[ES]

Esta actividad es optativa. Si no la has realizado ninguna estancia, elimina esta carpeta.

Si sí solicitaste irte de estancia y lo hiciste antes del 1 de octubre de 2024, lo hiciste en un documento PDF con título: "SOLICITUD Y ACEPTACIÓN DE ESTANCIA PARA OPTAR A LA MENCIÓN INTERNACIONAL EN EL TÍTULO DE DOCTOR". Coloca dicho documento en esta carpeta. 

Si además de irte de estancia antes del 1 de octubre de 2024, quieres optar a la mención internacional, NO debes hacer la solicitud de dicha mención en la aplicación Thesis. En su lugar, debes rellenar y firmar en PDF el documento "solicitud_mencion_doctorado_internacional_XXX.docx". Coloca dicho documento firmado en PDF en esta carpeta. Sustituye XXX por tus iniciales.

Si solicitaste irte de estancia después del 1 de octubre de 2024, lo hiciste por la plataforma Thesis. No es necesario que coloques ningún documento en esta carpeta. Elimina el documento "solicitud_mencion_doctorado_internacional_XXX.docx"; es solo para los que hicieron el procedimiento en 'papel', tú lo hiciste online. Además, si quieres optar a la mención internacional, debes solicitarla en la aplicación Thesis.

En cualquiera de los casos, rellena el documento "conformidad_capdib_mencion_internacional_XXX.docx" con los datos correspondientes y guárdalo en esta carpeta en formato 'docx'. Sustituye XXX por tus iniciales. La CAPD lo comprobará, firmará y enviará a la Escuela Internacional de Doctorado.

[EN]

This activity is optional. If you have not completed any stay, delete this folder.

If you did request to go on a stay and did so before October 1, 2024, you did so in a PDF document entitled: "SOLICITUD Y ACEPTACIÓN DE ESTANCIA PARA OPTAR A LA MENCIÓN INTERNACIONAL EN EL TÍTULO DE DOCTOR". Place that document in this folder.

If in addition to going on a stay before October 1, 2024, you want to opt for the international mention, you should NOT request said mention in the Thesis application. Instead, you must fill out and sign the "solicitud_mencion_doctorado_internacional_XXX.docx" document in PDF. Place that signed document in PDF in this folder. Replace XXX with your initials.

If you requested to go on a stay after October 1, 2024, you did so through the Thesis platform. It is not necessary to place any document in this folder. Delete the "solicitud_mencion_doctorado_internacional_XXX.docx" document; it is only for those who did the procedure on 'paper', you did it online. Also, if you want to opt for the international mention, you must request it in the Thesis application.

In any case, fill out the "conformidad_capdib_mencion_internacional_XXX.docx" document with the corresponding data and save it in this folder in 'docx' format. Replace XXX with your initials. The CAPD will check, sign, and send it to the International Doctoral School.