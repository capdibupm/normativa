[ES]

Coloca en esta carpeta todos los justificantes que se soliciten en el documento de actividades.


[EN]

Place in this folder all the justifications requested in the activities document.