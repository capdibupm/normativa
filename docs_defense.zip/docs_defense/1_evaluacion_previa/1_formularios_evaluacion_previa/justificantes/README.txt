[ES]

Coloca en cada carpeta todos los justificantes que se soliciten en el documento de actividades.

[EN]

Place in each folder all the justifications requested in the activities document.
