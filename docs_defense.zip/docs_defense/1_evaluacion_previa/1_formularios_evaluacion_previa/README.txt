[ES]

Aclaraciones sobre el documento de actividades
================================================

AF1: BÚSQUEDA BIBLIOGRÁFICA (Actividad obligatoria)
------------------------------------------------------

En la actividad formativa AF1 el curso recomendado es "ICE-UPM", pero no es el obligatorio elegir este curso en particular. Existen otras alternativas que pueden ser igualmente válidas, como por ejemplo:
- MOOC de UPM "Bases Metodológicas y de Documentación para la Investigación Científica" (https://eventos.upm.es/116146/detail/bases-metodologicas-y-de-documentacion-para-la-investigacion-cientifica.html)
- MOOC de Stanford en Coursera "Writing in the Sciences" (https://www.coursera.org/learn/sciwrite)


AF2: TÉCNICAS DE REDACCIÓN DE COMUNICACIONES EN CONGRESOS (Actividad obligatoria)
---------------------------------------------------------------------------------

En esta actividad formativa, la idea de "aprender", pensando que el director/es enseñan sobre cómo contribuir a conferencias y congresos. No necesitamos ninguna prueba de que has aprendido, sólo la firma del supervisor en el documento y un justificante de que se haya presentado, al menos, un trabajo en un congreso en el que seas autor o coautor. Aunque no hayas asistido tú como ponente, pero en el sí figura tu nombre.


AF4: ESTANCIAS EN OTRAS UNIVERSIDADES O CENTROS DE INVESTIGACIÓN (Actividad optativa)
-------------------------------------------------------------------------------------

Si has realizado una estancia en un centro extranjero, deberás aportar un justificante de la estancia firmado por el responsable del centro de destino. Así mismo, adjunta el informe sobre la actividad realizada.

Si solicitas la mención internacional **e hiciste la solicitud de estancia en papel antes del 01/10/2024**, además, debes incluir en la carpeta de justificantes una copia de aquél documento.


Aclaraciones sobre los indicios de calidad del programa
=======================================================

No hay que olvidar poner la URL del portal científico (https://portalcientifico.upm.es/es/ipublic/researcher/<IDinvestigador>) en la hoja "0_id".

Por motivos informativos solamente, la columna "COAUTOR EN TRIBUNAL" da información de si alguno de los miembros del tribunal propuestos comparte coautoría con el doctorando.

Para completar la información sobre el índice de impacto, aceptación y cuartil de las revistas, puedes usar la herramienta de FECYT: https://factor.recursoscientificos.fecyt.es

Para completar el índice de impacto de los congresos, puedes usar el GGS (https://scie.lcc.uma.es/ratingSearch.jsf) o el CORE (https://www.core.edu.au/).

Para completar el número de citas, puedes usar la herramienta de WoS (https://www.webofscience.com/wos/alldb/basic-search) o Google Scholar (https://scholar.google.es/).





[EN]

Clarifications on the activities document
=========================================

AF1: BIBLIOGRAPHIC SEARCH (Mandatory activity)
------------------------------------------------

In the training activity AF1 the recommended course is "ICE-UPM", but it is not mandatory to choose that one in particular. There are other alternatives that may be equally valid, such as:
- UPM MOOC "Bases Metodológicas y de Documentación para la Investigación Científica" (https://eventos.upm.es/116146/detail/bases-metodologicas-y-de-documentacion-para-la-investigacion-cientifica.html)
- Stanford MOOC on Coursera "Writing in the Sciences" (https://www.coursera.org/learn/sciwrite)


AF2: TECHNIQUES FOR WRITING PAPERS FOR CONFERENCES (Mandatory activity)
------------------------------------------------------------------------

In this training activity, the idea is to "learn", thinking that the supervisor/s teach you how to contribute to conferences and congresses. We do not need any proof that you have learned, only the supervisor's signature on the document and a justification that at least one paper has been presented at a conference in which you are the author or co-author. Even if you have not attended as a speaker, but your name appears in the paper.


AF4: STAYS IN OTHER UNIVERSITIES OR RESEARCH CENTERS (Optional activity)
------------------------------------------------------------------------

If you have carried out a stay in a foreign center, you must provide a certificate of the stay signed by the person in charge of the destination center. Also, attach the report on the activity carried out.

If you are applying for the international mention **and you submitted the stay request on paper before 01/10/2024**, you must also include a copy of that document in the justification folder.


Clarifications on the quality indicators of the program
=======================================================
Do not forget to put the URL of the scientific portal (https://portalcientifico.upm.es/es/ipublic/researcher/<IDinvestigador>) in the "0_id" sheet.

The "COAUTOR EN TRIBUNAL" indicates if any of the members of the tribunal shares co-authorship with the doctoral student. For information porpuses only.

To complete the information on the impact index, acceptance and quartile of the journals, you can use the FECYT tool: https://factor.recursoscientificos.fecyt.es

To complete the impact index of the conferences, you can use the GGS (https://scie.lcc.uma.es/ratingSearch.jsf) or the CORE (https://www.core.edu.au/).

To complete the number of citations, you can use the WoS tool (https://www.webofscience.com/wos/alldb/basic-search) or Google Scholar (https://scholar.google.es/).

