[ES]

Coloca en esta carpeta el borrador de la tesis que has enviado a los revisores externos.

¡Importante! Comprueba que en las páginas 1-3 se sigue estrictamente la plantilla de la normativa (https://www.upm.es/Estudiantes/Estudios_Titulaciones/Estudios_Doctorado) En particular, asegúrate de revisar estos fallos comunes:
- Nombre de los directores completo
- Posición de los directores
- Lugar de trabajo de los directores

En algunas ocasiones la Escuela Internacional de Doctorado (EID) considera que el documento "parece" un trabajo por compendio de artículos. Si no es tu caso, asegúrate de que no lo parezca en absoluto o en el momento de Solicitud de Depósito de Tesis, la EID te pedirá que lo modifiques retrasando el proceso.



[EN]

Place in this folder all the draft of the thesis that you have sent to the external reviewers.

Important! Check that pages 1-3 strictly follow the template of the regulations (https://www.upm.es/Estudiantes/Estudios_Titulaciones/Estudios_Doctorado) In particular, make sure to review these common mistakes:

- Full name of the directors
- Position of the directors
- Workplace of the directors

Sometimes the International Doctoral School (EID) considers that the document "seems" like a compendium of articles. If this is not your case, make sure it does not look like it at all or at the time of the Thesis Deposit Request, the EID will ask you to modify it, delaying the process.