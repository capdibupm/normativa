[ES]

Coloca en esta carpeta el borrador de la tesis que has enviado a los revisores externos.

¡Importante! Comprueba que en las páginas 1-3 se sigue estrictamente la plantilla de la normativa (https://www.upm.es/Estudiantes/Estudios_Titulaciones/Estudios_Doctorado) En particular, asegúrate de revisar estos fallos comunes:
- Nombre de los directores completo
- Posición de los directores
- Lugar de trabajo de los directores

[EN]

Place in this folder all the draft of the thesis that you have sent to the external reviewers.

Important! Check that pages 1-3 strictly follow the template of the regulations (https://www.upm.es/Estudiantes/Estudios_Titulaciones/Estudios_Doctorado) In particular, make sure to review these common mistakes:

- Full name of the directors
- Position of the directors
- Workplace of the directors