[ES]

Coloca en esta carpeta el informe de doctorado industrial firmado por el candidato, el representante de la empresa y el/los director/es. *(No existe plantilla.)* Si no, borra la carpeta `justificacion_doctorado_industrial`.

[EN]

Place in this folder the industrial doctorate report signed by the candidate, the company representative and the director/s. *(There is no template.)* If not, delete the `justificacion_doctorado_industrial` folder.