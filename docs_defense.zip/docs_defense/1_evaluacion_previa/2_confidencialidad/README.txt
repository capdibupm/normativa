[ES]

Coloca en esta carpeta todos los documentos firmados por los miembros del tribunal. Sustituye "XXX" por las iniciales de cada miembro del tribunal. 

¡Atención! Los miembros del tribunal y expertos externos deben usar firma electrónica siempre que sea posible. Es obligatoria para los residentes en España y para aquellos extranjeros que dispongan de ella. En caso de que un residente en el extranjero no cuente con firma electrónica, se aceptará provisionalmente una firma digital no certificada (por ejemplo, escaneada o mediante Adobe Reader). Debido al elevado número de expertos extranjeros sin firma electrónica, esta medida se mantendrá hasta que la UPM implemente un sistema alternativo para ellos.

[EN]

Place in this folder all the documents signed by the members of the panel. Replace "XXX" with the initials of each panel member.

Warning!: Both the panel proposal and the suitability reports must be electronically signed whenever possible. This is mandatory for residents in Spain and for foreign residents who have an electronic signature. For those abroad without one, a provisional non-certified digital signature (e.g., scanned or via Adobe Reader) is acceptable. Given the high number of foreign experts lacking an electronic signature, this measure will remain in effect until UPM implements an alternative system.