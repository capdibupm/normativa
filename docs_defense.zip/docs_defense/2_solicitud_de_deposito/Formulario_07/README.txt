[ES]

Coloca en esta carpeta todos los documentos firmados por los miembros del tribunal y evaluadores externos. Sustituye "XXX" por las iniciales de cada miembro del tribunal. 

Por favor, comprueba que los "Formulario_07_informe_idoneidad_evaluador_externo_XXX" tienen marcada la casilla "Acepto ser evaluador experto externo / I accept to be external evaluator".

***********************************************************************************************************
Si optas a mención internacional, tus evaluadores internacionales pueden considerarse expertos externos. Si ya presentaste los Formularios 07 de los evaluadores internacionales y van a participar como miembros o suplentes del tribunal, por favor, vuelve a copiar los documentos en esta carpeta para que queden todos los documentos del tribunal juntos.
***********************************************************************************************************

¡Atención! Los miembros del tribunal y expertos externos deben usar firma electrónica siempre que sea posible. Es obligatoria para los residentes en España y para aquellos extranjeros que dispongan de ella. En caso de que un residente en el extranjero no cuente con firma electrónica, se aceptará provisionalmente una firma digital no certificada (por ejemplo, escaneada o mediante Adobe Reader). Debido al elevado número de expertos extranjeros sin firma electrónica, esta medida se mantendrá hasta que la UPM implemente un sistema alternativo para ellos.

[EN]

Place in this folder all the documents signed by the members of the panel and external experts. Replace "XXX" with the initials of each panel member.

Please, check that the "Formulario_07_informe_idoneidad_evaluador_externo_XXX" have the box "Acepto ser evaluador experto externo / I accept to be external evaluator" checked.

***********************************************************************************************************
If you are applying for the international mention, your international evaluators can be considered external experts. If you have already submitted the Form 07s for the international evaluators and they will be participating as panel members or substitutes, please copy the files again to this folder so that all the panel documents are together.
***********************************************************************************************************

Warning!: Both the panel proposal and the suitability reports must be electronically signed whenever possible. This is mandatory for residents in Spain and for foreign residents who have an electronic signature. For those abroad without one, a provisional non-certified digital signature (e.g., scanned or via Adobe Reader) is acceptable. Given the high number of foreign experts lacking an electronic signature, this measure will remain in effect until UPM implements an alternative system.