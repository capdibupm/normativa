[ES]

Coloca en esta carpeta la memoria de tesis definitiva y el documento de respuesta a los revisores.

Recuerda enviar a todos los miembros del tribunal la memoria definitiva, el documento de respuesta a los revisores y el documento de actividades.

[EN]

Place in this folder the final thesis memory and the response document to the reviewers.

Remember to send all the members of the panel the final memory, the response document to the reviewers, and the activities document.