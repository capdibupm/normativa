[ES]

Coloca en esta carpeta todos los documentos firmados por los evaluadores externos. Sustituye "XXX" por las iniciales de cada evaluador. 

Por favor, comprueba que se ha marcado alguna de las casillas del apartado "¿Considera usted que esta tesis doctoral es apta para su defensa pública?"

¡Atención! Los expertos externos deben usar firma electrónica siempre que sea posible. Es obligatoria para los residentes en España y para aquellos extranjeros que dispongan de ella. En caso de que un residente en el extranjero no cuente con firma electrónica, se aceptará provisionalmente una firma digital no certificada (por ejemplo, escaneada o mediante Adobe Reader). Debido al elevado número de expertos extranjeros sin firma electrónica, esta medida se mantendrá hasta que la UPM implemente un sistema alternativo para ellos.

[EN]

Place in this folder all the documents signed by the external evaluators. Replace "XXX" with the initials of each evaluator.

Please, check that one of the boxes in the section "Do you consider that this doctoral thesis is suitable for its public defence?" has been checked.

Warning! The external experts must use electronic signature whenever possible. This is mandatory for residents in Spain and for foreign residents who have an electronic signature. For those abroad without one, a provisional non-certified digital signature (e.g., scanned or via Adobe Reader) is acceptable. Given the high number of foreign experts lacking an electronic signature, this measure will remain in effect until UPM implements an alternative system.