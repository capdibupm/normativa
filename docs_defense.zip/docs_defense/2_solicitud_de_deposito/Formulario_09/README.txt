[ES]

Usa el archivo `Formulario_09_respuesta_a_informes_de_evaluadores_externos.docx` para escribir la respuesta que enviarás a los evaluadores externos. Guárdalo en formato PDF y fírmalo, dejándolo en esta carpeta.

¡Atención! La firma electrónica es obligatoria para los residentes en España y para aquellos extranjeros que dispongan de ella.

[EN]

Use the file `Formulario_09_respuesta_a_informes_de_evaluadores_externos.docx` to write the response you will send to the external evaluators. Save it in PDF format and sign it, leaving it in this folder.

Attention! Electronic signature is mandatory for residents in Spain and for foreigners who have it.